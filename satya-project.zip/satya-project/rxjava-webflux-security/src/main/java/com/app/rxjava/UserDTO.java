package com.app.rxjava;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

public class UserDTO {
	@NotNull 
	@NotEmpty(message = "Firstname can't be empty")
	private String firstName;
	private String lastName;
	@Min(value = 10, message = "{age.min.requirement}")
	@Max(value = 50, message = "{age.max.requirement}")
	private int age;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	

}
