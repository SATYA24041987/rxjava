package com.app.rxjava;

import org.springframework.stereotype.Service;

import reactor.core.publisher.Mono;

@Service
public class UserService {
	
	public Mono<UserDTO> register(Mono<UserDTO> userDTO){
		return userDTO.doOnNext(System.out::println);
	}

}
