package com.app.rxjava;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/user")
public class AppController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/register")
	public Mono<UserDTO> register(@Valid @RequestBody Mono<UserDTO> userDTO){
		return userService.register(userDTO);
	}
	
	@GetMapping("/welcome")
	public String sayWelcome() {
		return "Welcome";
	}
	
}
