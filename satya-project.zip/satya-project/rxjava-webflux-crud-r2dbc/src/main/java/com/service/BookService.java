package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Book;
import com.repository.BookRepo;

import reactor.core.publisher.Mono;

@Service
public class BookService {
	
	@Autowired
	private BookRepo bookRepo;
	
	public Mono<Book> save(Book book){
		System.out.println(book);
		return bookRepo.save(book);
	}

}
