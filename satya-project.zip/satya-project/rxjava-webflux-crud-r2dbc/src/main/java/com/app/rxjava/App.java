package com.app.rxjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.r2dbc.connectionfactory.init.ConnectionFactoryInitializer;
import org.springframework.data.r2dbc.connectionfactory.init.ResourceDatabasePopulator;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

import com.repository.BookRepo;

import io.r2dbc.spi.ConnectionFactory;

@SpringBootApplication
@ComponentScan("com")
@EnableR2dbcRepositories(basePackageClasses = BookRepo.class)
 public class App 
{
    public static void main( String[] args )
    {
        SpringApplication.run(App.class, args);
    }
    @Bean
    ConnectionFactoryInitializer init(ConnectionFactory connectionFactory) {
    	ConnectionFactoryInitializer initializer= new ConnectionFactoryInitializer();
    	initializer.setConnectionFactory(connectionFactory);
    	initializer.setDatabasePopulator(new ResourceDatabasePopulator(new ClassPathResource("scheme.sql")));
    	
    	return initializer;
    }
}

