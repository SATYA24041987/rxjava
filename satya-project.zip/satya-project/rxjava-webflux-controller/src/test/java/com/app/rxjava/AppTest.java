package com.app.rxjava;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@RunWith(SpringRunner.class)
@WebFluxTest
public class AppTest {
	
	@Autowired
	WebTestClient webTestClient;
	
	//@Test
	public void test1() {
		Flux<Integer> intFlux = webTestClient.get().uri("/flux")
				.exchange()
				.expectStatus().isOk()
				.returnResult(Integer.class)
				.getResponseBody();
		
		StepVerifier.create(intFlux)
			.expectNext(1)
			.expectNext(2)
			.expectNext(3)
			.expectNext(4)
			.expectNext(5)
			.verifyComplete();
		
	}
	
	@Test
	public void test2() {
		webTestClient.get().uri("/flux")
			.exchange()
			.expectStatus().isOk()
			.expectBodyList(Integer.class)
			.hasSize(5);
		
	}
}
