package com.app.rxjava;

import java.util.Arrays;
import java.util.List;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class DemoOne {

	public Flux<String> nameFlux(){
		return Flux.just("Satya", "Prasad", "Himanth").log();
	}
	
	public Flux<String> nameFluxIterable(){
		List<String> list = Arrays.asList("Satya", "Prasad", "Himanth");
		return Flux.fromIterable(list);
	}
	
	public Flux<String> nameFluxMap(){
		List<String> list = Arrays.asList("Satya", "Prasad", "Himanth");
		return Flux.fromIterable(list)
				.map(String::toUpperCase);
	}
	
	public Flux<String> nameFluxFilter(int length){
		List<String> list = Arrays.asList("Satya", "Prasad", "Himanth");
		return Flux.fromIterable(list)
				.map(String::toUpperCase)
				.filter(s -> s.length() > length );
	}
	
	public Mono<String> nameMeno(){
		return Mono.just("Satya").log();
	}
	
	public static void main(String[] args) {
		DemoOne done = new DemoOne();
		//done.nameFlux().subscribe(name -> System.out.println(name));
		//done.nameFluxIterable().subscribe(name -> System.out.println(name));
		//done.nameFluxMap().subscribe(name -> System.out.println(name));
		//done.nameFluxFilter(5).subscribe(name -> System.out.println(name));
		done.nameMeno().subscribe(name -> System.out.println(name));
	}

}
