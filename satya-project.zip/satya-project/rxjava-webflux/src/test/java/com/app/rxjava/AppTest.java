package com.app.rxjava;

import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import java.util.List;

import org.junit.jupiter.api.Test;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

/**
 * Unit test for simple App.
 */
public class AppTest {
	DemoOne demoOne = new DemoOne();

	//@Test
	void nameFlux() {
		// when
//		Flux<String> list =  demoOne.nameFlux();
//		StepVerifier.create(list)
//		.expectNext("Satya", "Prasad", "Himanth")
//		.verifyComplete();

//		Flux<String> list =  demoOne.nameFlux();
//		StepVerifier.create(list)
//		.expectNext("Satya")
//		.expectNextCount(2)
//		.verifyComplete();

		Flux<String> list = demoOne.nameFluxMap();
		StepVerifier.create(list)
			.expectNext("SATYA")
			.expectNextCount(2)
			.verifyComplete();
	}

	//@Test
	void nameFluxFilter() {
		Flux<String> list = demoOne.nameFluxFilter(5);
		StepVerifier.create(list)
			.expectNext("PRASAD", "HIMANTH")
			.verifyComplete();
	}
	
	//@Test
	public void mergeTest() {
		Flux<String> flux1 = Flux.just("A", "B", "C").delayElements(Duration.ofSeconds(1)).log();
		Flux<String> flux2 = Flux.just("D", "E").delayElements(Duration.ofSeconds(1)).log();
		Flux<String> data = Flux.merge(flux1, flux2);
		
		StepVerifier.create(data)
		.expectNext("A", "B", "C", "D", "E")
		.verifyComplete();
	}
	
	@Test
	public void concatTest() {
		Flux<String> flux1 = Flux.just("A", "B", "C").delayElements(Duration.ofSeconds(1)).log();
		Flux<String> flux2 = Flux.just("D", "E").delayElements(Duration.ofSeconds(1)).log();
		Flux<String> data = Flux.concat(flux1, flux2, flux2);
		
		StepVerifier.create(data)
		.expectNext("A", "B", "C", "D", "E", "D", "E")
		.verifyComplete();
	}
}
