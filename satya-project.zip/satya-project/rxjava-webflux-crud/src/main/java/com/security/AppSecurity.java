package com.security;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.server.SecurityWebFilterChain;

@EnableWebFluxSecurity
public class AppSecurity {

	@Bean
	MapReactiveUserDetailsService userDetails() {
		UserDetails userDetails1 = User.withDefaultPasswordEncoder()
				.username("admin").password("admin123").roles("ADMIN").build();
		UserDetails userDetails2 = User.withDefaultPasswordEncoder()
				.username("admin").password("admin123").roles("ADMIN", "EMP").build();
		
		return new MapReactiveUserDetailsService(userDetails1, userDetails2);
	}
	
	@Bean
	public SecurityWebFilterChain filter(ServerHttpSecurity http) {
		
		http.authorizeExchange()
		.pathMatchers("/router2/**").permitAll()
		.pathMatchers(HttpMethod.GET,"/router3/**").hasRole("ADMIN")
		.anyExchange().authenticated().and().httpBasic().and().formLogin();
		return http.build();
	}
}
