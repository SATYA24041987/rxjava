package com.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.dao.CustomerDao;
import com.dto.Customer;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class CustomerHandler {

	@Autowired
	private CustomerDao customerDao;
	
	public Mono<ServerResponse> loadCustomers(ServerRequest request){
		Flux<Customer> customersList = customerDao.getCustomersData();
		 return ServerResponse.ok().body(customersList, Customer.class);
	}
	
	public Mono<ServerResponse> loadCustomerByID(ServerRequest request){
		int custID = Integer.valueOf(request.pathVariable("id"));
		Mono<Customer> customersList = customerDao.getCustomersData().filter(c -> c.getId() == custID).next();
		 return ServerResponse.ok().body(customersList, Customer.class);
	}
	
	public Mono<ServerResponse> saveCustomer(ServerRequest request){
		Mono<Customer> monoCust = request.bodyToMono(Customer.class);
		Mono<String> saveResp = monoCust.map(dto -> dto.getId() + ":" + dto.getName());
		 return ServerResponse.ok().body(saveResp, Customer.class);
	}
}
