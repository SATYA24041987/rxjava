package com.navigation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;
import com.handler.CustomerHandler;
import com.handler.CustomerStreamHandler;

@Configuration
public class NavigationApp {

	@Autowired
	CustomerHandler handler1;
	
	@Autowired
	CustomerStreamHandler handler2;
	
	@Bean
	public RouterFunction<ServerResponse> routerFunction(){
		return RouterFunctions.route()
				.GET("/router/loadcustomers", handler1::loadCustomers)
				.GET("/router/loadcustomer/{id}", handler1::loadCustomerByID)
				.POST("/router/saveCustomer", handler1::saveCustomer)
				.GET("/router/loadcustomersStream", handler2::loadCustomers)
				.build();
	}
	
	@Bean
	public RouterFunction<ServerResponse> routerFunction2(){
		return RouterFunctions.route()
				.GET("/router2/loadcustomers", handler1::loadCustomers)
				.GET("/router2/loadcustomer/{id}", handler1::loadCustomerByID)
				.build();
	}
	
	@Bean
	public RouterFunction<ServerResponse> routerFunction3(){
		return RouterFunctions.route()
				.GET("/router3/loadcustomers", handler1::loadCustomers)
				.GET("/router3/loadcustomer/{id}", handler1::loadCustomerByID)
				.build();
	}
}
