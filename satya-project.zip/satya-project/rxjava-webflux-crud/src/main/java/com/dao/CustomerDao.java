
package com.dao;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.stereotype.Component;

import com.dto.Customer;

import reactor.core.publisher.Flux;

@Component
public class CustomerDao {
	private static void  pause(int i) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public List<Customer> getCustomers(){
		return IntStream.rangeClosed(1, 10)
				.peek(CustomerDao ::pause)
				.peek(i -> System.out.println("Processing Count "+ i))
				.mapToObj(i -> new Customer(i, "Customer "+ i))
				.collect(Collectors.toList());
	}
	
	public Flux<Customer> getCustomersStream(){
		return Flux.range(1, 10)
				.delayElements(Duration.ofSeconds(1))
				.doOnNext(i -> System.out.println("Count is: " + i))
				.map(i -> new Customer(i, "Customer "+ i));
	}
	
	public Flux<Customer> getCustomersData(){
		return Flux.range(1, 10)
				.doOnNext(i -> System.out.println("Count is: " + i))
				.map(i -> new Customer(i, "Customer "+ i));
	}
}
