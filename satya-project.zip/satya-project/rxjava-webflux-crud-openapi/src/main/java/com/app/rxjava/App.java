package com.app.rxjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@ComponentScan("com")
@SpringBootApplication
@OpenAPIDefinition(info = @Info(
		title = "Spring webflux Doc",
		version = "1.2.3",
		description = "Internal Documentation of Spring webflux"
		))
public class App
{
    public static void main( String[] args )
    {
        SpringApplication.run(App.class, args);
    }
}
