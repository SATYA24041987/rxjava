package com.app.rxjava;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class AppController {

	@Autowired
	private ItemRepo itemRepo;
	
	@GetMapping("/loadData")
	public Flux<Item> returnFlux(){
		return itemRepo.findAll();
	}
	
	@PostMapping("/save")
	public Mono<Item> saveIteam(@RequestBody Item item){
		return itemRepo.save(item);
	}

}
