package com.app.rxjava;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface ItemRepo extends ReactiveMongoRepository<Item, String>{
	



}
