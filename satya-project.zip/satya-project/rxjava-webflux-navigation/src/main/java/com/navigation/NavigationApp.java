package com.navigation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.handler.AppHandler;

@Configuration
public class NavigationApp {

	@Bean
	public RouterFunction<ServerResponse> route(AppHandler handler){
		return RouterFunctions.route(GET("/functional/loaddata"), handler::flux)
				.andRoute(GET("/functional/loaddata2"), handler::flux2);
	}
}
