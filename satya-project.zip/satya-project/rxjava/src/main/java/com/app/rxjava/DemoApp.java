package com.app.rxjava;

import java.util.Arrays;
import java.util.List;

import io.reactivex.Observable;

public class DemoApp {

	public static void main(String[] args) {
		//createObsWithJust();
		//createObsFromIterable();
		createObs();
	}

	private static void createObsWithJust() {
		Observable<Integer> obs = Observable.just(1,2,3,4,5,6,7);
		obs.subscribe(item -> System.out.println("item:" + item));
	} 
	
	private static void createObsFromIterable() {
		List<Integer> list = Arrays.asList(1,2,3,4,5,6);
		Observable<Integer> obs = Observable.fromIterable(list);
		obs.subscribe(item -> System.out.println("item:" + item));
	}
	
	private static void createObs() {
		Observable<Integer> obs = Observable.create(emitter -> {
			emitter.onNext(1);
			emitter.onNext(2);
			emitter.onNext(3);
			emitter.onNext(4);
			emitter.onNext(5);
			//emitter.onNext(null);
			emitter.onComplete();
		});
		
		obs.subscribe(item -> System.out.println("item:" + item),
				error -> System.out.println(error),
				() -> System.out.println("Completed the flow"));
	}
}
