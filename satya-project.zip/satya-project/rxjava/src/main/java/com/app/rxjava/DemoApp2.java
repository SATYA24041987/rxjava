package com.app.rxjava;

import io.reactivex.Observable;
import io.reactivex.observables.ConnectableObservable;

public class DemoApp2 {

	public static void main(String[] args) {
		//createObsWithJust();
		createHotObs();
	}
	
	// Cold observer
	private static void createObsWithJust() {
		Observable<Integer> obs = Observable.just(1,2,3,4,5,6,7);
		obs.subscribe(item -> System.out.println("Subs1:" + item));
		pause(5000);
		obs.subscribe(item -> System.out.println("Subs2:" + item));
	} 
	
	// Hot observer
	private static void createHotObs() {
		ConnectableObservable<Integer> obs =  Observable.just(1,2,3,4,5).publish();
		obs.subscribe(item -> System.out.println("Subs1:" + item));
		obs.connect();
		//pause(5000);
		obs.subscribe(item -> System.out.println("Subs2:" + item));
	}
	
	private static void pause(int duration) {
		try {
			Thread
			.sleep(duration);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
