package com.app.rxjava;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( String[] args )
    {
        System.out.println( "Hi Satya Prasad");
    }
}
